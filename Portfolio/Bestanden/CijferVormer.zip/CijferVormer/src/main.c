
/*
KNOP 2 OP ARDUINO LANG INGEDRUKT HOUDEN!!! 
*/

#define __DELAY_BACKWARD_COMPATIBLE__
#include <util/delay.h>
#include <avr/io.h>
#include <display.h>
#include <usart.h>
#include <avr/interrupt.h>
#include <led.h>
#include <stdlib.h>
#include <stdio.h>

#define LED_PORT PORTB
#define BUTTON_PORT PORTC
#define BUTTON_PIN PINC
#define LED_DDR DDRB
#define BUTTON_DDR DDRC
#define BUTTON1 PC1
#define BUTTON2 PC2
#define BUTTON3 PC3
#define LED1 PB2
#define LED2 PB3
#define LED3 PB3
#define LED4 PB4

#define SCROLLING_TEXT "CIJFERVORMER"
#define SCROLLING_TEXT_SPEED 10 //1-50 (fast - slow)

uint8_t levens = 4;
uint8_t teBouwenNummer;
uint8_t level = 0;

const uint8_t SEGMENT_MAPS[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99,
                                0x92, 0x82, 0xF8, 0X80, 0X90};

const uint8_t FSEGMENT[] = {0x86, 0xCF, 0xC8, 0xA1};




uint8_t rollingBit = 0; //brandende segment
uint8_t rollbit = 0;    // timer voor volgende segment
uint8_t rollbitEND = 0;
uint8_t rollingBitEND = 0;
uint8_t startGame = 0;               //nodig om loop te stoppen
uint8_t progressCijfer = 0b11111111; // lege Digit
uint8_t swotch = 0;
uint8_t prog[] = {0b11111111, 0b11111111, 0b11111111, 0b11111111};

int counter = 0;   //<----- globaal timer
uint16_t aantalStrepen = 0 ;

struct logBoek
{
    uint8_t Level;
    uint16_t aantalStrepen;
    uint8_t levens;
    float tijd;
};




void printlogBoek(struct logBoek *logboek)
{
    for (int i = 0; i < level; i++)
    {
        printf("\n level%d: %d -\t  %d -\t  %d -\t  %fSec", i, (logboek + i)->Level, (logboek + i)->aantalStrepen, (logboek + i)->levens, (((logboek + i)->tijd)/400)); // 400 counts per Seconden aleen in game telt 
    }
}

void playTone(float frequency, uint32_t duration)
{
  uint32_t periodInMicro = (uint32_t)(1000000 / frequency); //we berekenen de periode in microseconden uit de frequency
  uint32_t durationInMicro = duration * 1000;               //we willen duration in microseconden
  for (uint32_t time = 0; time < durationInMicro; time += periodInMicro)
  {
    PORTD &= ~(1 << PD3);
    _delay_us(periodInMicro / 2);
    PORTD |= (1 << PD3);
    _delay_us(periodInMicro / 2);
  }
}

void potentioSeed()
{
  ADMUX |= (1 << REFS0);                                // reference voltage. 5V als reference voltage
  ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); //bepalen van de samplerate door een deelfactor 128
  ADCSRA |= (1 << ADEN);                                //Enable de ADC
  for (size_t i = 0; i < 5; i++)
  {
    ADCSRA |= (1 << ADSC);
    loop_until_bit_is_clear(ADCSRA, ADSC);
    uint16_t value = ADC;
    int AValue = abs((value * 10) - 230);
    srand(AValue);
  };
}

int bitvalue(int8_t num, int bit)
{
  if (bit >= 0 && bit <= 8)
  {
    return ((num >> (bit)) & 1);
  }
  else
    return 0;
}

void showInfo(uint8_t level, uint8_t rollingsegment, uint8_t doneSegments, uint8_t numbertoBuild)
{
  writeNumberToSegment(0, level);
  _delay_ms(2);
  lightUpSegments(1, rollingsegment);
  _delay_ms(2);
  lightUpSegments(2, doneSegments);
  _delay_ms(2);
  writeNumberToSegment(3, numbertoBuild);
  _delay_ms(2);
  lightDownLed(levens);
}



void initEnd()
{

  if (swotch == 0)
  {
    for (uint8_t i = 0; i < 4; i++)
    {
      while (prog[i] != FSEGMENT[i])
      {
        _delay_ms(5);
        rollingBitFuncEND();

        if (bitvalue(FSEGMENT[i], rollbitEND) == 0) //juiste lege segment word overgenomen
        {
          prog[i] = prog[i] & rollingBitEND;
        }
        lightUpSegments(i, prog[i]);
        
      }
    }
    swotch = 1;
  }
  showEND();


}

void showEND(){
 _delay_ms(5);
    lightUpSegments(0, prog[0]);
    _delay_ms(5);
    lightUpSegments(1, prog[1]);
    _delay_ms(5);
    lightUpSegments(2, prog[2]);
    _delay_ms(5);
    lightUpSegments(3, prog[3]);

}

void rollingBitFuncEND()
{
//  if (counter % 20 == 0)
 // {
    rollbitEND = rand() % 7;
    rollingBitEND = ~(1 << rollbitEND);
    showEND();
 // }
}

uint8_t buttonPressed(uint8_t button)
{
  if (bit_is_clear(PINC, button))
  {
    _delay_us(1000);
    if (bit_is_clear(PINC, button))
    {
      return 1;
    }
  }
  return 0;
}

// void initTimer() {
//     TCCR0A |= _BV(WGM00) | _BV(WGM01); // Fast PWM Mode
//     TCCR0B |= _BV(CS02) | _BV(CS00); // prescalerfactor 1024
//     TIMSK0 |= _BV(OCIE0A); // OCRA interrupt enablen
//     sei(); // interrupts globaal enablen
// }

// // deze ISR runt telkens wanneer TCNT0 gelijk is aan de waarde in het OCRA-register
// ISR(TIMER0_COMPA_vect)
// {
//   counter++;
//   printf("counter %d \n = ", counter);

// }

struct logBoek *logboekPtr;  //<<-- pointer


ISR(PCINT1_vect)
{
  uint8_t b = SEGMENT_MAPS[teBouwenNummer];

  if (buttonPressed(PC3) && startGame == 1) //Zorgt voor het selecteren van de rollingbit
  {
   
    
    
    

    //printf("BUTTEN PRESSED ONCE");

    if (bitvalue(progressCijfer, rollbit) == 0)
    {

      playTone(1000, 100);
      levens--;
    }

    if (bitvalue(b, rollbit) == 1)
    {
      playTone(1000, 100);
      levens--;
    }

    if (bitvalue(b, rollbit) == 0) //juiste lege segment word overgenomen
    {

      progressCijfer = progressCijfer & rollingBit;
      aantalStrepen++;

      for (int i = 0; i < 2; i++)
      {
        playTone(2000, 50);
      }
    }

    if (b == progressCijfer)
    {
      progressCijfer = 0b11111111;
      teBouwenNummer = (rand() % 9);
      level++;
      logboekPtr = (struct logBoek *)malloc(11 * sizeof(struct logBoek));  // elke level een Array bijhouden
      (logboekPtr+level)->Level = level;
      (logboekPtr+level)->aantalStrepen = aantalStrepen;
      (logboekPtr+level)->levens = levens;
      (logboekPtr+level)->tijd = counter;
      
       for (int i = 0; i < 3; i++)
      {
        playTone(300, 50);
        _delay_ms(50);
        playTone(400, 50);
        _delay_ms(50);
        playTone(1000, 50);
        _delay_ms(50);
      }
    }
  }

  if (buttonPressed(PC2))
  {
    startGame = 1;
  }
  if (buttonPressed(PC3))
  {
  }
}

void rollingBitFunc(int rolSnelheid)
{ // zorgt voor de beweging DIGIT 2 en INDEX
  if (counter % rolSnelheid == 0)
  {
    rollbit = rand() % 7; //in text staat RANDOM
                          //   rollbit++; //--> verander dees met bovenstaande als je een patroon wil. code hier onder heeft geen nut zonder rollbit++
                          //   if (rollbit == 7)
                          //   {
                          //     rollbit = 0;
                          //     rollingBit = ~(1 << rollbit);
                          //   }
    rollingBit = ~(1 << rollbit);
  }
}

void playgame()
{
  for (uint8_t i = 0; i < 4; i++)
  {
    prog[i] = 0b11111111;
  }
  
  startGame = 1;
  teBouwenNummer = (rand() % 9);

  if (teBouwenNummer == 4){
    playTone(200, 200);
    playTone(200, 10);
    playTone(200, 50);
  }


  {
    /* code */
  }
  

  lightUpAllLeds();
  levens = 4;

  while (level != 9)
  {
    counter++;
    rollingBitFunc(70 - (level * 7)); //10% sneller elke level omhoog
    showInfo(level, rollingBit, progressCijfer, teBouwenNummer);
    if (levens == 0)
    {
      lightDownLed(0);
  playTone(6000, 200);
  _delay_ms(100);
  playTone(5000, 200);
  _delay_ms(100);
  playTone(3000, 200);
  _delay_ms(100);
  playTone(500, 500);
  _delay_ms(100);
      initEnd();
      break;
    }
  }


  printf("VERLOREN LOGBOEK : ");

  printlogBoek(&logboekPtr);

  writeScrollingText("PROBEER OPNIEUW", SCROLLING_TEXT_SPEED);
  progressCijfer = 0b11111111;
  level = 0;
  startGame = 0;
  return;
}

int main()
{

  
  

  initDisplay();
  initUSART();
  enableAllLeds();
  DDRD |= (1 << PD3);  // buzzer enabelen
  PORTD |= (1 << PD3); //buzzer uit
  uint8_t runOnce = 0;
  // initTimer();

  BUTTON_DDR &= ~((_BV(BUTTON1)) + (_BV(BUTTON2)) + (_BV(BUTTON3))); // we gaan knop1 gebruiken
  BUTTON_PORT |= ((_BV(BUTTON1)) + (_BV(BUTTON2)) + (_BV(BUTTON3))); // pull up aanzetten
  PCICR |= _BV(PCIE1);
  PCMSK1 |= _BV(BUTTON1);
  PCMSK1 |= _BV(BUTTON3);
  sei();

  while (startGame == 0)
  {
    
    if ((PINC & 0b00000100) == 0) //
    {
         writeStringAndWait("]]]]",10);
         playgame();
    }
      writeScrollingText(SCROLLING_TEXT, SCROLLING_TEXT_SPEED);

    if (runOnce == 0)
    {
      potentioSeed();
      
      runOnce++;
    }
  }
}
